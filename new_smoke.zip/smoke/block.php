<?php

if (!file_exists("data")) {
    mkdir("data", 0777, true);
}

$spam_file = "data/spam_list.json";

if (!file_exists($spam_file)) {
    file_put_contents($spam_file, json_encode([]));
}

function isSpamDevice($device_id) {
    global $spam_file;
    if (empty($device_id)) return false;
    if (!file_exists($spam_file)) return false;
    $spam_list = json_decode(file_get_contents($spam_file), true);
    if (!is_array($spam_list)) return false;
    return in_array($device_id, $spam_list);
}

function addSpamDevice($device_id) {
    global $spam_file;
    if (empty($device_id)) return false;
    $spam_list = json_decode(file_get_contents($spam_file), true);
    if (!is_array($spam_list)) $spam_list = [];
    if (!in_array($device_id, $spam_list)) {
        $spam_list[] = $device_id;
        file_put_contents($spam_file, json_encode($spam_list));
        return true;
    }
    return false;
}

function removeSpamDevice($device_id) {
    global $spam_file;
    if (empty($device_id)) return false;
    $spam_list = json_decode(file_get_contents($spam_file), true);
    if (!is_array($spam_list)) $spam_list = [];
    $spam_list = array_values(array_diff($spam_list, [$device_id]));
    file_put_contents($spam_file, json_encode($spam_list));
    return true;
}

function getSpamDevices() {
    global $spam_file;
    if (!file_exists($spam_file)) return [];
    $spam_list = json_decode(file_get_contents($spam_file), true);
    return is_array($spam_list) ? $spam_list : [];
}
?>